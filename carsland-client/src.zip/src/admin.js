const data = require('./data/data');

function makeCar() {



}


function makeCarModel() {


}


