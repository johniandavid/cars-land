import {Col, Container, Row} from "react-grid-system";

function About() {
    return(
            <div className="about">
                <div className="slide">
                    <Container>
                        <Row>
                            <Col sm={12} md={9} lg={7} xl={6} className="text-left">
                                <h1>Software Engineer & Mobile App Developer based in LA</h1>
                                <h4>Dedicated to creating innovative solutions that can positively impact the lives of others. </h4>
                            </Col>
                        </Row>
                    </Container>
                </div>
                <div className="slide">
                    <Container>
                        <Row>
                            <Col sm={12} md={9} lg={7} xl={6} className="text-left">
                                <h1>I’m a creative, results-driven software engineer who can build state-of-the-art and user-friendly applications</h1>
                                <h4> I aspire to use my passion for technology as a driving force to tackle everyday social issues.</h4>
                            </Col>
                        </Row>
                    </Container>
                </div>
            </div>
        )
}

export default About