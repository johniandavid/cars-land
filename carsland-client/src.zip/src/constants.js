var config  = require('./config.json');

export const API_INVOKE_URL = config["api"]["invokeUrl"];
export const AUTH_TOKEN = config["api"]["auth_key"];